# Time Traveling File System

This is a simple version-controlled file system implemented in C++. It allows creating files, updating content, taking snapshots, rolling back to previous versions, and viewing file history. Inspired by git, the system manages file versions in a tree structure and supports fast retrieval using custom data structures like heaps and hash maps.

---

## Features

- Create files and maintain versions over time
- Insert and update content with version tracking
- Take snapshots with messages for rollback points
- Rollback to the last version or any snapshot by version ID
- View snapshot history with timestamps and messages
- List files based on:
  - Most recent modifications
  - Highest number of versions

---

## How it Works

Each file is represented as a tree of versions (`TreeNode`). Whenever content is added or updated, a new version node is created (unless the previous node was not a snapshot). Snapshots are stored with timestamps and messages to allow rollback.

Versions are tracked using a custom hash map for fast lookup by version ID. Files are also stored in two heaps:

- One for most recently modified files (`RecentHeapFile`)
- One for files with the most versions (`BiggestHeapTree`)

---

## Example Usage

```cpp
FileSystem fs;

fs.CREATE("notes.txt");
fs.INSERT("notes.txt", "Hello, world.");
fs.SNAPSHOT("notes.txt", "Initial draft");

fs.UPDATE("notes.txt", "Hello, universe.");
fs.SNAPSHOT("notes.txt", "Final draft");

fs.HISTORY("notes.txt");

fs.ROLLBACK("notes.txt", 1); // Rollback to version 1

fs.RECENT_FILES();    // Lists files by last modified
fs.BIGGEST_TREES();   // Lists files by number of versions

