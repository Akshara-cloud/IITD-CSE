#include<iostream>
#include<vector>
using namespace std;

static time_t t = 1;
struct TreeNode {
    int version_id;
    string content;
    string message; // empty string if not a snapshot
    time_t created_timestamp;
    time_t snapshot_timestamp; // initialize to 0 if not a snapshot
    TreeNode* parent;
    vector<TreeNode*> children;
    TreeNode(int v_id, string c, time_t created) {
        version_id = v_id;
        content = c;
        message = "";
        created_timestamp = t++;
        snapshot_timestamp = 0;
        parent = nullptr;
    }
};

class HashMap { //version ID's are the keys, it's TreeNode is the value
    static const int n = 1000;
    vector<pair<int, TreeNode*>> table[n]; //vectors of sizes n containing pairs of version-ids and nodes
public:
    HashMap() {
    }
    void push(int key, TreeNode* val) {
        int i = key%n;
        for(auto& it : table[i]) {
            if(it.first==key) {
                it.second=val;
                return;
            }
        }
        table[i].push_back({key, val});
    }
    TreeNode* get(int key) {
        int i= key%n;
        for(auto& it: table[i]) {
            if(it.first==key) return it.second;
        }
        return nullptr;
    }
};

class File {
    string file_name;
    TreeNode* root;
    TreeNode* active_version;
    HashMap versions;
    int total_versions;
    time_t last_modified;
public:
    File(string name) {
        file_name = name;
        root = new TreeNode(0, "", t++);
        active_version = root;
        total_versions = 1;
        last_modified = t++;
        versions.push(0, root);
        root->snapshot_timestamp = t++;
        root->message = "empty snapshot";
    }
    string getName() {
        return file_name;
    }
    time_t getLastModified() {
        return last_modified;
    }
    int getTotalVersions() {
        return total_versions;
    }
    void read() {
        if(!active_version) cout<<"Error: No active versions"<<endl;
        else cout<<active_version->content<<endl;
    }
    void insert(string content) {
        if(active_version==root|| active_version->snapshot_timestamp!=0) { // add the content to the child, else replace the current node's content
            TreeNode* temp = new TreeNode(total_versions, active_version->content+content,t++);
            temp->parent = active_version;
            active_version->children.push_back(temp);
            active_version = temp;
            versions.push(total_versions, temp);
            total_versions++;
        }
        else {
            active_version->content += content;
            active_version->created_timestamp = t++;
        }
        last_modified = t++; //update this everytime
    }
    void update(string content) {
        if(active_version==root||active_version->snapshot_timestamp!=0) {
            TreeNode* temp = new TreeNode(total_versions,content, time(0));
            temp->parent = active_version;
            active_version->children.push_back(temp);
            active_version = temp;
            versions.push(total_versions, temp);
            total_versions++;
        }
        else {
            active_version->content = content;
            active_version->created_timestamp = t++;
        }
        last_modified = t++;
    }
    void snapshot(string msg) {
        active_version->message = msg;
        active_version->snapshot_timestamp = t++;
        last_modified = t++;
    }
    void rollback() {
        if(active_version&& active_version->parent) {
            if (active_version->parent) active_version = active_version->parent;
        }
        else cout<<"Error: cannot Rollback"<<endl;
    }
    void rollback(int version_id) {
        TreeNode* curr = versions.get(version_id);
        if(curr) {
            active_version = curr;
        }
        else cout<<"Error: versionID not found"<<endl;
    }
    void history() {
        vector<TreeNode*> branchsnapshots;
        TreeNode* curr= active_version;
        while(curr!=nullptr) {
            if(curr->snapshot_timestamp!=0) {
                branchsnapshots.push_back(curr);
            }
            curr= curr->parent;
        }
        int n = int(branchsnapshots.size());
        for(int i=0;i<n;i++) {
            TreeNode* node = branchsnapshots[i];
            cout << "VersionID: " <<" "<< node->version_id <<", timestamp: " <<node->snapshot_timestamp<<", message: "<< node->message << endl;
        }
    }
};

class RecentHeapFile {  //heap sort done according to their last modfiied time
    vector<File*> Rheap;
public:
    void insert(File* f) {
        for (auto it = Rheap.begin(); it != Rheap.end(); it++) { //how you can use a hashmap over here, you can actually use them by
            if ((*it)->getName() == f->getName()) {
                Rheap.erase(it);
                break;
            }
        }
        int n = int(Rheap.size());
        Rheap.push_back(f);
        int num = n;
        while(num>0) {
            int parent = (num-1)/2;
            if(Rheap[parent]->getLastModified()<=Rheap[num]->getLastModified()) {
                swap(Rheap[parent], Rheap[num]);
                num = parent;
            }
            else break;
        }
    }
    File* remove_max() {
        if(Rheap.empty()) return nullptr;
        File* root = Rheap[0];
        int n = int(Rheap.size());
        Rheap[0] = Rheap[n-1];
        Rheap.pop_back();
        n--;
        int num = 0;
        while (true) {
            int left = 2*num + 1;
            int right = 2*num + 2;
            int largest = num;
            if (left < n && Rheap[left]->getLastModified()> Rheap[largest]->getLastModified()) largest = left;
            if (right < n && Rheap[right]->getLastModified()> Rheap[largest]->getLastModified()) largest = right;
            if (largest != num) {
                swap(Rheap[num], Rheap[largest]);
                num = largest;
            }
            else break;
        }
        return root;
    }
    void listall() {
        vector<File*> copy = Rheap;
        RecentHeapFile heap;
        heap.Rheap = copy;
        while(!heap.Rheap.empty()) {
            File* root = heap.remove_max();
            cout<<root->getName()<<endl;
        }
    }
};

class BiggestHeapTree {  //heap sort done according to their total version count
    vector<File*> Bheap;
public:
    void insert(File* f) {
        for (auto it = Bheap.begin(); it != Bheap.end(); it++) {
            if ((*it)->getName() == f->getName()) {
                Bheap.erase(it);
                break;
            }
        }
        int n = int(Bheap.size());
        Bheap.push_back(f);
        int num = n;
        while(num>0) {
            int parent = (num-1)/2;
            if(Bheap[parent]->getTotalVersions()<=Bheap[num]->getTotalVersions()) {
                swap(Bheap[parent], Bheap[num]);
                num = parent;
            }
            else break;
        }
    }
    File* remove_max() {
        if(Bheap.empty()) return nullptr;
        File* root = Bheap[0];
        int n = int(Bheap.size());
        Bheap[0] = Bheap[n-1];
        Bheap.pop_back();
        n--;
        int num = 0;
        while (true) {
            int left = 2*num + 1;
            int right = 2*num + 2;
            int largest = num;
            if (left < n && Bheap[left]->getTotalVersions() > Bheap[largest]->getTotalVersions()) largest = left;
            if (right < n && Bheap[right]->getTotalVersions() > Bheap[largest]->getTotalVersions()) largest = right;
            if (largest != num) {
                swap(Bheap[num], Bheap[largest]);
                num = largest;
            }
            else break;
        }
        return root;
    }
    void listall() {
        vector<File*> copy = Bheap;
        BiggestHeapTree heap;
        heap.Bheap = copy;
        while(!heap.Bheap.empty()) {
            File* root = heap.remove_max();
            cout<<root->getName()<<endl;
        }
    }
};

class FileSystem {
    vector<File*> files;
    RecentHeapFile Rheap;
    BiggestHeapTree Bheap;
    int fileindex(string filename) {
        int n = int(files.size());
        for(int i=0; i<n;i++) {
            if(files[i]->getName() == filename) return i;
        }
        return -1;
    }
public:
    void CREATE(string filename) {
        if(fileindex(filename)==-1) {
            File* file = new File(filename);
            files.push_back(file);
            Rheap.insert(file);
            Bheap.insert(file);
        }
    }
    void READ(string filename) {
        int i = fileindex(filename);
        if(i==-1) cout<<"Error: No file created"<<endl;
        else files[i]->read();
    }
    void INSERT(string filename, string content) {
        int i = fileindex(filename);
        if(i==-1) cout<<"Error: No file created"<<endl;
        else {
            files[i]->insert(content);
            Rheap.insert(files[i]);
            Bheap.insert(files[i]);
        }
    }
    void UPDATE(string filename, string content) {
        int i = fileindex(filename);
        if(i==-1) cout<<"Error: No file created"<<endl;
        else {
            files[i]->update(content);
            Rheap.insert(files[i]);
            Bheap.insert(files[i]);
        }
    }
    void SNAPSHOT(string filename, string message) {
        int i = fileindex(filename);
        if(i==-1) cout<<"Error: No file created"<<endl;
        else {
            files[i]->snapshot(message);
            Rheap.insert(files[i]);
            Bheap.insert(files[i]);
        }
    }
    void ROLLBACK(string filename, int version_id) {
        int i = fileindex(filename);
        if(i==-1) cout<<"Error: No file created"<<endl;
        else {
            files[i]->rollback(version_id);
            Rheap.insert(files[i]);
            Bheap.insert(files[i]);
        }
    }
    void HISTORY(string filename) {
        int i = fileindex(filename);
        if(i==-1) cout<<"Error: No file created"<<endl;
        else files[i]->history();
    }
    void RECENT_FILES() {
        Rheap.listall();
    }
    void BIGGEST_TREES() {
        Bheap.listall();
    }
};
