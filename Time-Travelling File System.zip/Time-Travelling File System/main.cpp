#include "File.cpp"

int main() {
    FileSystem fs;
    string command;
    while(cin >> command) {
        if(command == "CREATE") {
            string filename;
            cin>>filename;
            fs.CREATE(filename);
        }
        if(command == "READ") {
            string filename;
            cin>>filename;
            fs.READ(filename);
        }
        if(command == "INSERT") {
            string filename, content;
            cin>>filename>>content;
            fs.INSERT(filename, content);
        }
        if(command == "UPDATE") {
            string filename, content;
            cin>>filename>>content;
            fs.UPDATE(filename, content);
        }
        if(command == "SNAPSHOT") {
            string filename, message;
            cin>>filename>>message;
            fs.SNAPSHOT(filename, message);
        }
        if(command == "ROLLBACK") {
            string filename;
            int version_id;
            cin>>filename>>version_id;
            fs.ROLLBACK(filename, version_id);
        }
        if(command == "HISTORY") {
            string filename;
            cin>>filename;
            fs.HISTORY(filename);
        }
        if(command == "RECENT_FILES") fs.RECENT_FILES();
        if(command == "BIGGEST_TREES") fs.BIGGEST_TREES();
    }
}
